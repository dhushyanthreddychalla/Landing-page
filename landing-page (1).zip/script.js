/* ============================================================
   SCRIPT.JS — NexaFlow Landing Page
   Handles: sticky nav, mobile menu, scroll reveal,
            smooth scroll, contact form, active nav links,
            footer year.
   ============================================================ */

'use strict';

/* ── 1. NAVBAR: STICKY ON SCROLL ─────────────────────────── */
const navbar = document.getElementById('navbar');

/**
 * Adds .scrolled class to navbar when page scrolls past 50px,
 * triggering the frosted-glass backdrop effect.
 */
function handleNavScroll() {
  if (window.scrollY > 50) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
}

window.addEventListener('scroll', handleNavScroll, { passive: true });
handleNavScroll(); // Run once on load in case page starts scrolled


/* ── 2. MOBILE MENU: HAMBURGER TOGGLE ─────────────────────── */
const hamburger = document.getElementById('hamburger');
const navLinks  = document.getElementById('navLinks');

/**
 * Toggles the mobile navigation open/closed.
 * Updates aria-expanded for accessibility.
 */
function toggleMenu() {
  const isOpen = navLinks.classList.toggle('open');
  hamburger.classList.toggle('active');
  hamburger.setAttribute('aria-expanded', isOpen);
  // Prevent body scroll while menu is open
  document.body.style.overflow = isOpen ? 'hidden' : '';
}

hamburger.addEventListener('click', toggleMenu);

// Close menu when a nav link is clicked
navLinks.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('open');
    hamburger.classList.remove('active');
    hamburger.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  });
});

// Close menu on outside click
document.addEventListener('click', (e) => {
  if (!navbar.contains(e.target) && navLinks.classList.contains('open')) {
    navLinks.classList.remove('open');
    hamburger.classList.remove('active');
    hamburger.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  }
});


/* ── 3. SCROLL REVEAL ─────────────────────────────────────── */
/**
 * Uses IntersectionObserver to add .visible to elements
 * with the .reveal class as they enter the viewport.
 * Falls back gracefully if IntersectionObserver is unavailable.
 */
function initScrollReveal() {
  const revealEls = document.querySelectorAll('.reveal');

  if (!('IntersectionObserver' in window)) {
    // Fallback: show all elements immediately
    revealEls.forEach(el => el.classList.add('visible'));
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        // Once revealed, unobserve to save resources
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.12,   // trigger when 12% of element is visible
    rootMargin: '0px 0px -40px 0px'
  });

  revealEls.forEach(el => observer.observe(el));
}

initScrollReveal();


/* ── 4. ACTIVE NAV LINK HIGHLIGHT ON SCROLL ──────────────── */
/**
 * Highlights the correct nav link based on which section
 * is currently in view, using IntersectionObserver.
 */
function initActiveNav() {
  const sections  = document.querySelectorAll('section[id]');
  const navAnchors = document.querySelectorAll('.nav-link');

  if (!('IntersectionObserver' in window)) return;

  const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');
        navAnchors.forEach(a => {
          // Match anchor href to section id
          const href = a.getAttribute('href');
          if (href === `#${id}`) {
            a.style.color = 'var(--clr-white)';
          } else {
            a.style.color = '';
          }
        });
      }
    });
  }, {
    threshold: 0.4  // section must be 40% visible to activate
  });

  sections.forEach(s => sectionObserver.observe(s));
}

initActiveNav();


/* ── 5. CONTACT FORM: VALIDATION + SUBMISSION ─────────────── */
const contactForm  = document.getElementById('contactForm');
const formSuccess  = document.getElementById('formSuccess');

/**
 * Handles form submission with basic client-side validation.
 * In a real project, replace the simulate block with a
 * fetch() call to your backend or a service like Formspree.
 */
contactForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const fname   = contactForm.fname.value.trim();
  const lname   = contactForm.lname.value.trim();
  const email   = contactForm.email.value.trim();
  const message = contactForm.message.value.trim();

  // — Basic validation —
  if (!fname || !lname) {
    showFormError('Please enter your full name.');
    return;
  }
  if (!isValidEmail(email)) {
    showFormError('Please enter a valid email address.');
    return;
  }
  if (message.length < 10) {
    showFormError('Message must be at least 10 characters.');
    return;
  }

  // — Simulate async submission —
  const submitBtn = contactForm.querySelector('button[type="submit"]');
  submitBtn.disabled = true;
  submitBtn.textContent = 'Sending…';

  try {
    await simulateSubmit({ fname, lname, email, message });

    // Success state
    formSuccess.textContent = `✓ Message sent! We'll be in touch shortly, ${fname}.`;
    formSuccess.style.color = 'var(--clr-teal)';
    contactForm.reset();
  } catch (err) {
    formSuccess.textContent = '⚠ Something went wrong. Please try again.';
    formSuccess.style.color = 'var(--clr-amber)';
  } finally {
    submitBtn.disabled = false;
    submitBtn.innerHTML = 'Send message <i class="ph ph-paper-plane-tilt"></i>';
    // Clear success/error message after 5 seconds
    setTimeout(() => { formSuccess.textContent = ''; }, 5000);
  }
});

/** Displays a form-level error message. */
function showFormError(msg) {
  formSuccess.textContent = `⚠ ${msg}`;
  formSuccess.style.color = 'var(--clr-amber)';
  setTimeout(() => { formSuccess.textContent = ''; }, 4000);
}

/** Basic email format check. */
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/**
 * Simulates a 1.2s async server round-trip.
 * Replace with a real API call in production:
 *
 *   await fetch('https://your-api.com/contact', {
 *     method: 'POST',
 *     headers: { 'Content-Type': 'application/json' },
 *     body: JSON.stringify(data)
 *   });
 */
function simulateSubmit(data) {
  console.log('Form data:', data);
  return new Promise(resolve => setTimeout(resolve, 1200));
}


/* ── 6. FOOTER: DYNAMIC YEAR ─────────────────────────────── */
const yearEl = document.getElementById('year');
if (yearEl) yearEl.textContent = new Date().getFullYear();


/* ── 7. SMOOTH SCROLL FOR IN-PAGE ANCHORS ─────────────────── */
/**
 * Intercepts clicks on anchor links starting with '#' and
 * scrolls smoothly to the target, offsetting for the fixed navbar.
 */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', (e) => {
    const target = document.querySelector(anchor.getAttribute('href'));
    if (!target) return;

    e.preventDefault();
    const navHeight = navbar.offsetHeight;
    const top = target.getBoundingClientRect().top + window.scrollY - navHeight - 12;

    window.scrollTo({ top, behavior: 'smooth' });
  });
});


/* ── 8. HERO PARALLAX (subtle) ────────────────────────────── */
/**
 * Moves the hero orbs at different speeds as the user scrolls,
 * creating a depth effect. Only runs above 768px wide.
 */
function initParallax() {
  const orb1 = document.querySelector('.orb-1');
  const orb2 = document.querySelector('.orb-2');

  if (!orb1 || !orb2) return;

  window.addEventListener('scroll', () => {
    if (window.innerWidth < 768) return;
    const y = window.scrollY;
    orb1.style.transform = `translate(${y * 0.04}px, ${y * 0.06}px)`;
    orb2.style.transform = `translate(${y * -0.03}px, ${y * -0.04}px)`;
  }, { passive: true });
}

initParallax();
