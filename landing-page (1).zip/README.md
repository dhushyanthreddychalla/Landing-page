# NexaFlow — Landing Page

A modern, responsive, single-page landing page built with pure HTML, CSS, and JavaScript.
Suitable for internship/portfolio submissions.

---

## Folder Structure

```
landing-page/
├── index.html     ← Main HTML (all sections)
├── style.css      ← All styles (tokens, layout, animations)
├── script.js      ← All interactivity (nav, form, scroll reveal)
└── README.md      ← This file
```

No build tools, no dependencies, no npm. Just open and run.

---

## How to Run

### Option A — Open directly in browser (simplest)
1. Download or unzip the project folder.
2. Double-click `index.html`.
3. It opens in your default browser. Done.

### Option B — Live Server in VS Code (recommended for development)
1. Install **VS Code** → https://code.visualstudio.com
2. Install the **Live Server** extension (by Ritwick Dey).
3. Open the `landing-page/` folder in VS Code.
4. Right-click `index.html` → **Open with Live Server**.
5. Your browser opens at `http://127.0.0.1:5500`.
6. Any file save auto-refreshes the page.

### Option C — Python local server
```bash
cd landing-page
python3 -m http.server 3000
# Open http://localhost:3000
```

---

## Expected Output — Section Descriptions

### Navbar
- Dark frosted-glass bar at the top (transparent at page top, blurred when scrolled).
- Left: gradient "N" logo mark + "NexaFlow" wordmark.
- Right: About, Services, Features, Contact links + "Get Started" violet button.
- Mobile: collapses to a hamburger that animates into an ✕ on tap.

### Hero Section
- Full-height screen; deep navy background with three slow-floating gradient orbs (violet, teal, amber).
- Badge pill: "✦ Trusted by 500+ companies worldwide".
- Large display heading: "Build products that move people." — with teal-to-violet gradient on the second line.
- Subheading in muted text.
- Two CTA buttons: solid gradient "Start for free" + ghost "▶ See how it works".
- Row of three frosted stat chips: 99.9% Uptime / 3× Faster / 500+ Integrations.

### About Section
- Two-column grid: copy on the left, a feature card on the right.
- Card shows "12K+ Active teams" in gradient numerals, then a divider, then four security bullet points with teal checkmarks.

### Services Section
- Dark surface background. Three equal cards in a row.
- Each card: coloured icon box, title, description, "Learn more →" link.
- Center card is "featured" with a subtle gradient fill and "Most popular" badge.
- Cards lift and glow violet on hover.

### Features Section
- Six two-column feature items in a 3×2 grid (2×3 on tablet, 1×6 on mobile).
- Each: violet icon box + bold title + body text.
- Subtle border appears on hover.

### Contact Section
- Split layout: contact info (email, phone, address) on the left, a form card on the right.
- Form: first/last name row, email, message textarea, submit button.
- Live validation + simulated async submit with success/error feedback.

### Footer
- Logo + tagline + four social icons (X, LinkedIn, GitHub, YouTube) with hover glow.
- Three link columns: Product / Company / Legal.
- Bottom bar with dynamic copyright year.

---

## Key Technical Features

| Feature | Implementation |
|---------|----------------|
| Smooth scroll | CSS `scroll-behavior: smooth` + JS offset for fixed navbar |
| Sticky navbar | `IntersectionObserver` / scroll event → `.scrolled` class |
| Mobile menu | CSS transform slide-down + JS class toggle |
| Scroll reveal | `IntersectionObserver` → `.visible` class with CSS transition |
| Active nav link | `IntersectionObserver` on sections |
| Hero parallax | scroll event → inline transform on orb elements |
| Form validation | JS regex + length checks before simulated submit |
| Responsive | CSS Grid + `clamp()` fluid sizing, three breakpoints |
| Reduced motion | `@media (prefers-reduced-motion: reduce)` respected |
| Accessibility | `aria-label`, `aria-expanded`, semantic HTML5 elements |
